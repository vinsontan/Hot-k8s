#!/bin/bash

kubectl apply -f manifests/sockshop-app/canary/

