# Dynatrace-Dashboards
Dynatrace Dashboards (ver 162) Uses Session Properties and USQL
Templates based on JSON from https://github.com/TechShady/Dynatrace-Dashboards
